About AGMIS

AGMIS is an Agricultural Reports Managements System that is being developed by Evolution Media Group Uganda

for Mr Andrew Hyeroba to help users obtain information about prices of agricultural products especially in Uganda.
