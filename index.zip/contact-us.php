<?php include 'inc/header.php'; ?>

<img src="img/g.png" class="img-responsive" style="width:100%; height:20%;">

<br>dsa

<?php
echo $userRow['ap_uname'];
?>
