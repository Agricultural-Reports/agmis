
<!--Footer-->

<section class="contact">
    <hr>
    <div class="container">
        <div class="col-md-3">
            <ul style="list-style: none;">
                <li>Write for Us</li>
                <li>Books</li>
                <li>Mentorship</li>
                <li>Licensing</li>
            </ul>
        </div>

        <div class="col-md-3">
            <ul style="list-style: none;">
                <li>Write for Us</li>
                <li>Books</li>
                <li>Mentorship</li>
                <li>Licensing</li>
            </ul>
        </div>


        <div class="col-md-2">
            <ul style="list-style: none;">
                <li>Write for Us</li>
                <li>Books</li>
                <li>Mentorship</li>
                <li>Licensing</li>
            </ul>
        </div>



        <script>(function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=727084914091193";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>


        <div class="col-md-4">

            <div class="fb-page"
                 style="margin-left:0px;width:100%;";
                 data-href="https://www.facebook.com/evolutionmediagroupug"
                 data-width="380"
                 data-hide-cover="false"
                 data-show-facepile="true"
                 data-show-posts="false"> Facebook Page Loading...</div>

        </div>


        <div class="col-md-4 text-center center-block" id="social-icons">
            <div id="content">
                <i class="fa fa-facebook-square"></i>
                <i class="fa fa-twitter-square"></i>
                <i class="fa fa-linkedin-square"></i>
                <i class="fa fa-google-plus-square"></i>
                <i class="fa fa-globe"></i>

                <hr color="#fff">
                <p style="font-size:20px;">&copy; AGMIS <?php echo date('Y'); ?></p>
            </div>
        </div>
</div>
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>

        </body>

